/*vraag1 = prompt("Vul een getal tussen de 1 en de 10 in.");
vraag2 = prompt("Vul een getal boven de 2 in.");


if (vraag1 < 1 || vraag1 > 10) {
    alert("VUL EEN GETAL TUSSEN DE 1 EN DE 10 IN");
  } 

document.write("<p> x",  "(", vraag1, ")", "tot de macht y", "(", vraag2, ")",  "= ", Math.pow(vraag1,vraag2), "</p>");*/

g1 = Math.floor(Math.random() * (10 - 1 + 1) ) + 1;
g2 = Math.floor(Math.random() * (10 - 2 + 1) ) + 2;

document.write("<p> ",g1 ,  " tot de macht ", g2 , " = ",  Math.pow(g1,g2), "</p>")



document.write("<p> de wortel van ", g1, " = ", Math.sqrt(g1))


