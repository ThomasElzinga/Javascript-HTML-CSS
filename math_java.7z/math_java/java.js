var opp = (10.25*5.85);
document.write("<p> oppervlakte = ", opp," m2", "</p>");
document.write("<p> oppervlakte afgerond = ",Math.round (opp)," m2", "</p>");
document.write("<p> oppervlakte afgerond naar beneden = ",Math.floor (opp)," m2", "</p>");
document.write("<p> oppervlakte afgerond naar boven = ",Math.ceil (opp)," m2", "</p>");