function Splitten() {
    var totaal = parseFloat(document.querySelector("#totaal").value);
    document.querySelector("#totaal").innerHTML = totaal;

    var amensen = parseInt(document.querySelector("#amensen").value);
    document.querySelector("#amensen").innerHTML = amensen;

    var fooi = parseFloat(document.querySelector("#fooi").value);
    document.querySelector("#fooi").innerHTML = fooi;
    
    if (fooi >0) {berekening = (totaal + fooi) / amensen}
    else {berekening = totaal/amensen}
     
    afronden = berekening.toFixed(2);

    document.write("<p> Bedrag pp.€", afronden, "</p>");
    //document.getElementById("toonbedrag").innerHTML = afronden;
}
