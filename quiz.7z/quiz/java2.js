function toon() {
  var v1 = parseInt(document.querySelector("#v1").value);
  document.querySelector("#v1").innerHTML = v1;
  
  var v2 = (document.querySelector("#v2").value);
  document.querySelector("#v2").innerHTML = v2;
  
  var v3 = (document.querySelector("#v3").value);
  document.querySelector("#v3").innerHTML = v3;
  
  var v4 = parseInt(document.querySelector("#v4").value);
  document.querySelector("#v4").innerHTML = v4;
  
  var v5 = (document.querySelector("#v5").value);
  document.querySelector("#v5").innerHTML = v5;
  
  var v6 = parseInt(document.querySelector("#v6").value);
  document.querySelector("#v6").innerHTML = v6;
  
  var v7 = (document.querySelector("#v7").value);
  document.querySelector("#v7").innerHTML = v7;
  
  var v8 = (document.querySelector("#v8").value);
  document.querySelector("#v8").innerHTML = v8;
  
  var v9 = (document.querySelector("#v9").value);
  document.querySelector("#v9").innerHTML = v9;
  
  var v10 = (document.querySelector("#v10").value);
  document.querySelector("#v10").innerHTML = v10;
    
  uitslag = 0
  
  if (v1.value="6" ) {
    punten1 = "Goed";
    uitslag +=1
  } else {
    punten1 = "Fout";
    }
  
  if (v2.value="September") {
    punten2 = "Goed";
    uitslag +=1
  } else {
    punten2 = "Fout";
    }
      
  if (v3.value="Google") {
    punten3 = "Goed";
    uitslag +=1
  } else {
    punten3 = "Fout";
    }
      
  if (v4.value="31") {
    punten4 = "Goed";
    uitslag +=1
  } else {
    punten4 = "Fout";
    }
      
  if (v5.value="Weekend") {
    punten5 = "Goed";
    uitslag +=1
  } else {
    punten5 = "Fout";
    }
  
  if (v6.value="24") {
    punten6 = "Goed";
    uitslag +=1
  } else {
    punten6 = "Fout";
    }
  
  if (v7.value="Oor") {
    punten7 = "Goed";
    uitslag +=1
  } else {
    punten7 = "Fout";
    }
      
  if (v8.value="Krimpen") {
    punten8 = "Goed";
    uitslag  +=1
  } else {
    punten8 = "Fout";
    }
      
  if (v9.value="Openbaar Vervoer") {
    punten9 = "Goed";
    uitslag +=1
  } else {
    punten9 = "Fout";
    }
      
  if (v10.value="Achtbaan") {
    punten10 = "Goed";
    uitslag +=1
  } else {
    punten10 = "Fout";
    }
  
  
      
  document.write("<h3>1.Hoeveel zijdes heeft een dobbelsteen? </h3>")
  document.write("<p> Jouw antwoord op vraag1 is ", punten1, "</p>")
  
  document.write("<h3>2.In welke maand begint de herfst?</h3>")
  document.write("<p> Jouw antwoord op vraag 2 is ", punten2, "</p>")
  
  document.write("<h3>3.Hoe heet de meest bekende zoekmachine op het internet?</h3>")
  document.write("<p> Jouw antwoord op vraag 3 is ", punten3, "</p>")
  
  document.write("<h3>4.Hoeveel dagen heeft de maand augustus?</h3>")
  document.write("<p> Jouw antwoord op vraag 4 is ", punten4, "</p>")
  
  document.write("<h3>5.Hoe worden zaterdag en zondag samen vaak genoemd?</h3>")
  document.write("<p> Jouw antwoord op vraag 5 is ", punten5, "</p>")
  
  document.write("<h3>6.Hoeveel uur duurt een etmaal?</h3>")
  document.write("<p> Jouw antwoord op vraag 6 is ", punten6, "</p>")
  
  document.write("<h3>7.Waarvoor staat de O bij een KNO-arts?</h3>")
  document.write("<p> Jouw antwoord op vraag 7 is ", punten7, "</p>")
  
  document.write("<h3>8.Het tegenoverstelde van groeien is?</h3>")
  document.write("<p> Jouw antwoord op vraag 8 is ", punten8, "</p>")
  
  document.write("<h3>9.Waarvoor staat de afkorting OV in de OV-chipkaart?</h3>")
  document.write("<p> Jouw antwoord op vraag 9 is ", punten9, "</p>")
  
  document.write("<h3>10.Welk attractie bedoelen de Engelsen met rollercoaster</h3>")
  document.write("<p> Jouw antwoord op vraag 10 is ", punten10, "</p>")
  
  
  if (uitslag <5) {document.write("<p>Helaas, onvoldoende</p>")}
  if (uitslag == 6 || uitslag == 7) {document.write("<p>Netjes, voldoende</p>")}
  if (uitslag == 8 || uitslag == 9) {document.write("<p>Goed gedaan, bijna alles goed</p>")}
  if (uitslag == 10) {document.write("<p>Perfect, niets meer aan doen</p>")}
  
  
}