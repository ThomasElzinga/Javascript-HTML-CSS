function rapport() {
naam = prompt("vul hier je naam in");
nederlands = prompt("Vul hier je Nederlands cijfer in.");
fries = prompt("Vul hier je Fries cijfer in.");
engels = prompt("Vul hier je Engels cijfer in.");
rekenen = prompt("Vul hier je cijfer van Rekenen in.");
frontend = prompt("Wat is je cijfer voor Frontend Programmeren.");
backend = prompt("Wat is je cijfer voor Backend Programmeren.");

gemiddelde = ((nederlands/6)+(fries/6)+(engels/6)+(rekenen/6)+(frontend/6)+(backend/6));
afgerond = gemiddelde.toFixed(1)

document.getElementById("naam").innerHTML = "Rapport van: " + naam  ;
document.getElementById("nl").innerHTML =  "Nederlands = " + nederlands  ;
document.getElementById("fr").innerHTML =  "Fries  = " + fries  ;
document.getElementById("en").innerHTML =  "Engels = " + engels  ;
document.getElementById("re").innerHTML =  "Rekenen = " + rekenen ;
document.getElementById("fron").innerHTML = "Frontend Programmeren = " + frontend  ;
document.getElementById("ba").innerHTML = "Backend Programmeren = " + backend  ;
document.getElementById("gm").innerHTML = "Je gemiddelde = " + afgerond  ;

}


function myFunction() {  
    if (afgerond < 5.5) 
        alert("Helaas " + naam + ", je gemiddelde is: " + afgerond + " dat is helaas te laag je bent niet geslaagd.");
    else 
        alert("Gefeliciteerd " + naam + ", je bent Geslaagd met het gemiddelde van: " + afgerond);
 
}

